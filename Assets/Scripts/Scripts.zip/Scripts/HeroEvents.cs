using MightyHeroes.Core.EventSystem;
using MightyHeroes.Gameplay.Hero.Payloads;

namespace MightyHeroes.Gameplay.Hero.Events
{
    /// <summary>
    /// Provides access to all hero-related gameplay events.
    /// Used to signal hero lifecycle milestones to other systems.
    /// </summary>
    public sealed class HeroEvents : EventGroupBase
    {
        /// <summary>
        /// Creates the hero events group using the shared event registry.
        /// </summary>
        /// <param name="registry">Shared event registry instance.</param>
        public HeroEvents(IEventRegistry registry)
            : base(registry)
        {
        }

        /// <summary>
        /// Raised when the hero completes their action phase.
        /// Used by the Turn FSM to advance the turn flow.
        /// </summary>
        public GameEvent<HeroTurnEndedPayload> HeroTurnEndedEvent =>
            Registry.GetEvent<HeroTurnEndedPayload>();

        /// <summary>
        /// Raised when hero hit reaction animation has fully completed.
        ///
        /// This event is critical for synchronizing hero combo flow with enemy reactions.
        /// </summary>
        public GameEvent<HeroHitReactionEndedPayload> HeroHitReactionEndedEvent =>
            Registry.GetEvent<HeroHitReactionEndedPayload>();

        /// <summary>
        /// Raised when the hero hits an enemy with an attack.
        /// </summary>
        public GameEvent<HeroAttackHitPayload> HeroAttackHitEvent =>
            Registry.GetEvent<HeroAttackHitPayload>();

        /// <summary>
        /// Raised when the hero begins the victory turn animation.
        /// Consumed by VictoryCameraController to trigger camera close-in.
        /// </summary>
        public GameEvent<HeroVictoryTurnStartedPayload> HeroVictoryTurnStartedEvent =>
            Registry.GetEvent<HeroVictoryTurnStartedPayload>();

        /// <summary>
        /// Raised when the hero enters the victory idle loop.
        /// Consumed by Victory UI panel to trigger fade-in.
        /// </summary>
        public GameEvent<HeroVictoryIdleStartedPayload> HeroVictoryIdleStartedEvent =>
            Registry.GetEvent<HeroVictoryIdleStartedPayload>();

        /// <summary>
        /// Raised when the hero starts an attack sequence.
        /// </summary>
        public GameEvent<HeroAttackStartedPayload> HeroAttackStartedEvent =>
            Registry.GetEvent<HeroAttackStartedPayload>();

        // HeroEvents.cs'e ekle:
        public GameEvent<HeroAttackSequenceEndedPayload> HeroAttackSequenceEndedEvent =>
            Registry.GetEvent<HeroAttackSequenceEndedPayload>();

    }
}